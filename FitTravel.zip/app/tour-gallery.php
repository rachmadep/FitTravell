<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tour-gallery extends Model
{
    //
}
