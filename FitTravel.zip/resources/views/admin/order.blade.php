@extends('layouts.admin')
{{-- Page title --}}
@section('title', 'Orders')

@section('content')
<h1>test</h1>
@endsection