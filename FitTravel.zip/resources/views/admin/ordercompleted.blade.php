@extends('layouts.admin')
{{-- Page title --}}
@section('title', 'Orders Completed')

@section('content')
<h1>test</h1>
@endsection