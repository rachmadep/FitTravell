@extends('layouts.admin')
{{-- Page title --}}
@section('title', 'Sales History')

@section('content')
<h1>test</h1>
@endsection