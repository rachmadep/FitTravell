@extends('layouts.app')

@section('content')

<!-- Header  Inner style-->
<section class="row final-inner-header">
    <div class="container">
        <h2 class="this-title">Booking</h2>
    </div>
 </section>
 <section class="row final-breadcrumb">
    <div class="container">
        <ol class="breadcrumb">
            <li><a href="/">Home</a></li>
            <li class="">Tour</li>
            <li class="active">Chackout</li>
        </ol>
    </div>
 </section>
<!-- Header  Slider style-->

<!-- Booking style-->
  <section class="container clearfix common-pad-inner booknow">
    <div class="sec-header">
         <h2>Chackout</h2>
             <h3>Billing details</h3>
         </div> 
        
     <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 pull-left">
         
         <div class="book-left-content input_form">
          <form action="/" method="post" id="contactBooking"> 
            <div class="row">
                <h3>Create Account</h3>
            </div>        
           <div class="row">   
           <div class="col-lg-6 col-md-6 col-sm-12 m0 col-xs-12"><input type="text" class="form-control" id="name" name="name" placeholder="Your name"></div>   
            <div class="col-lg-6 col-md-6 col-sm-12 m0 col-xs-12"><input type="email" class="form-control" id="email" name="email" placeholder="Your Email"></div>
            </div>  
              
            <div class="row">   
               <div class="col-lg-12 col-md-12 col-sm-12 m0 col-xs-12"><input class="form-control" placeholder="Alamat" name="arival_date" type="text"></div>   
               <div class="col-lg-12 col-md-12 col-sm-12 m0 col-xs-12"><input class="form-control" placeholder="Email" name="arival_date" type="text"></div>
               <div class="col-lg-12 col-md-12 col-sm-12 m0 col-xs-12"><input class="form-control" placeholder="Account Password" name="arival_date" type="password"></div>
            </div>

              
            
              
              <div class="row">
                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><button type="submit" class="res-btn">Submit Now</button></div>
              </div>
              
              
          </form>
          </div>
         
         
         </div>
        <div class="col-sm-4 pull-right chackout-box">
            <div class="chackout-header">
                <h3>Have an account?</h3>
                <a href=""><h4>Login here</h4></a>
            </div>
         <div class="chackout-table">
             <table class="chackout-table1 table table-border">
                <thead>
                    <tr>
                        <th class="product-name">Tour</th>
                        <th class="product-total">Price</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="cart_item">
                        <td class="product-name">
                            HONEYMOON LOMBOK          
                        </td>
                        <td class="product-total">
                            Rp 8.000.0000
                        </td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr class="cart-subtotal">
                        <th>Subtotal</th>
                        <td>Rp 8.000.000</td>
                    </tr>
    
                    <tr class="order-total">
                        <th>Total</th>
                        <td>Rp 8.000.000</td>
                    </tr>
                </tfoot>
            </table>
         </div>  
      
      </div>
    
    </section> 
    
<!-- Booking style-->

@endsection
