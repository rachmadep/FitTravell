<?php $__env->startSection('title', 'Invoice'); ?>

<?php $__env->startSection('content'); ?>

<!-- Header  Inner style-->
<section class="row final-inner-header" style="background: url(<?php echo e(asset('img/slider/slide1.jpg')); ?>);background-size: cover;background-position: center;">
    <div class="container">
        <h2 class="this-title">Chackout</h2>
    </div>
 </section>
 <section class="row final-breadcrumb">
    <div class="container">
        <ol class="breadcrumb">
            <li><a href="/">Home</a></li>
            <li class="">Tour</li>
            <li class="">Booking</li>
            <li class="active">Chackout</li>
        </ol>
    </div>
 </section>
<!-- Header  Slider style-->



<section class="container clearfix common-pad-inner booknow">
<div id="printableArea">
  <div class="row">
    <div class="col-md-4">
      <div class="head-text-type1">
        <div class="sec-header">
         <h2>Invoice</h2>
             
             <p>Invoice Number : 13232</p>
             <p>Date : 15/12/2018</p>
        </div> 
        
          
      </div>
    </div>
    <div class="col-md-4">
      <div class="">
        <h3>Invoiced To :</h3>
        <p>Name : Sofyan Aji</p>
        <p>Phone Number : 123123</p>
        <p>E-mail : user@user.com</p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="">
        <h3>Status : Not yet paid</h3>
        <p>Payment deadline : 1/1/2019</p>
        <p>Bank : Bank Mandiri</p>
        <p>Account number : 88812138014824</p>
        <p>On behalf of the : Saya Yaa He Be De</p>
        <p>Reference number : 4134</p>
      </div>
    </div>
  </div>
  <div class="container-fluid">
      <div class="boxed">
        <div class="row">
          <h3>PURCHASE DETAILS</h3>
        </div>
      </div>
      <div class="boxed">
          <div class="shopping-cart">
              <div class="row">
                  <div class="col-lg-4 col-md-4 col-sm-4 hidden-xs">
                      <span class="col-name">Item</span>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-4 hidden-xs">
                      <span class="col-name text-left">Detail</span>
                  </div>
                  
                  <div class="col-lg-4 col-md-4 col-sm-4 hidden-xs">
                      <span class="col-name">Price</span>
                  </div>
              </div>

              <div class="row">
                  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                      <span class="col-name">Tour</span>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                      <span class="col-name">PAKET HONEYMOON LOMBOK</span>
                  </div>
                  
                  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                      <span class="col-name">Rp 8.000.000</span>
                  </div>
              </div>
              <div class="row">
                  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                      <span class="col-name">Person</span>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                      <span class="col-name">2 Persons</span>
                  </div>
                  
                  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                      <span class="col-name"></span>
                  </div>
              </div>
              <div class="row">
                  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                      <span class="col-name">Duration</span>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                      <span class="col-name">4 Day 3 Night</span>
                  </div>
                  
                  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                      <span class="col-name"></span>
                  </div>
              </div>
              <div class="row">
                  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                      <span class="col-name">Departure</span>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                      <span class="col-name">7/1/2019</span>
                  </div>
                  
                  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                      <span class="col-name"></span>
                  </div>
              </div>


              
        

              
              <div class="row">


                  <div class="col-md-4 col-sm-4 invoice-summary" id="printableArea">
                      <div class="curtain">
                          <div class="row">
                              <div class="col-lg-5 col-md-5 col-sm-4 col-sm-offset-1 col-md-offset-0 col-xs-5">
                                  <span class="h3">Total</span>
                              </div>
                              <div class="col-lg-6 col-md-6 col-sm-7 col-xs-6">
                                  <span class="h3">Rp 8.000.000</span>
                              </div>

                          </div>
                      </div>
                  </div>
              </div>
              <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <a href="javascript:printDiv('printableArea');" class="btn btn-primary active">Cetak Invoice</a>
                    
                </div>
              </div>

          </div>
      </div>
  </div>
</div>
</section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script language="javascript" type="text/javascript">
   function printDiv(divID) {
       //Get the HTML of div
       var divElements = document.getElementById(divID).innerHTML;
       //Get the HTML of whole page
       var oldPage = document.body.innerHTML;

       //Reset the page's HTML with div's HTML only
       document.body.innerHTML =
         "<html><head><title></title></head><body>" +
         divElements + "</body>";

       //Print Page
       window.print();

       //Restore orignal HTML
       document.body.innerHTML = oldPage;
   }
</script>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>