<?php $__env->startSection('title'); ?>
<?php echo e($tour->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

 <!-- Header  Inner style-->
<section class="row final-inner-header" style="background: url(/img/tour/<?php echo e($tour->image); ?>);background-size: cover;background-position: center;">
    <div class="container">
        <h2 class="this-title"><?php echo e($tour->name); ?></h2>
    </div>
 </section>
 <section class="row final-breadcrumb">
    <div class="container">
        <ol class="breadcrumb">
            <li><a href="index.html">Home</a></li>
            <li class="">Tour</li>
            <li class="active"><?php echo e($tour->name); ?></li>
        </ol>
    </div>
 </section>
<!-- Header  Slider style-->

<section class="container clearfix common-pad-inner">
<div class="row">      
    <div class="col-md-8">
        <div class="row detail-category">
            <div class="col-md-6">
                <div class="date-icon">
                    <i class="fa fa-clock-o"></i> <p><?php echo e($tour->duration); ?></p>
                </div>
            </div>

            <div class="col-md-6">
                <div class="date-icon">
                    <i class="fa fa-tag"></i> 
                    <p>
                        <?php $__currentLoopData = $tourcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $category->categoryname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="#"><?php echo e($name->name); ?></a>,
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p> 
                </div>
            </div>
        </div>
        
       
        <div class="single-room-wrapper">
         <!-- Rooms Slider style-->
            <div class="room-slider-wrapper">
                <div class="single-r-wrapper">
                    <div class="single-sl-room">
                        <div class="owl-itemm" data-hash="zero"><img src="/img/tour/<?php echo e($tour->image); ?>" alt=""></div>
                        <div class="owl-itemm" data-hash="one"><img src="/img/tour/<?php echo e($tour->image); ?>" alt=""></div>
                        <div class="owl-itemm" data-hash="two"><img src="/img/tour/<?php echo e($tour->image); ?>" alt=""></div>
                        <div class="owl-itemm" data-hash="three"><img src="/img/tour/<?php echo e($tour->image); ?>" alt=""></div>
                        <div class="owl-itemm" data-hash="four"><img src="/img/tour/<?php echo e($tour->image); ?>" alt=""></div>
                    </div>  
                      <a class="button secondary url" href="#zero"><img src="/img/tour/<?php echo e($tour->image); ?>" alt=""></a> 
                      <a class="button secondary url" href="#one"><img src="/img/tour/<?php echo e($tour->image); ?>" alt=""></a> 
                      <a class="button secondary url" href="#two"><img src="/img/tour/<?php echo e($tour->image); ?>" alt=""></a> 
                      <a class="button secondary url" href="#three"><img src="/img/tour/<?php echo e($tour->image); ?>" alt=""></a> 
                      <a class="button secondary url" href="#four"><img src="/img/tour/<?php echo e($tour->image); ?>" alt=""></a> 
               </div>
              
            </div>
           
          <!-- Rooms Slider style-->

            <div class="our-res">
                <div class="tab-title-box">
                    <ul class="clearfix" role="tablist">
                        <li class="active" data-tab-name="description">
                            <a href="#description" aria-controls="description" role="tab" data-toggle="tab">Description</a>
                        </li>
                        <li data-tab-name="facilities">
                            <a href="#facilities" aria-controls="facilities" role="tab" data-toggle="tab">Facilities</a>
                        </li>
                        <li data-tab-name="schedule">
                            <a href="#schedule" aria-controls="schedule" role="tab" data-toggle="tab">Schedule</a>
                        </li>
                        <li data-tab-name="bring">
                            <a href="#bring" aria-controls="bring" role="tab" data-toggle="tab">Things to Bring</a>
                        </li>
                        <li data-tab-name="term">
                            <a href="#term" aria-controls="term" role="tab" data-toggle="tab">Term & Conditions</a>
                        </li>
                        <li data-tab-name="price">
                            <a href="#price" aria-controls="price" role="tab" data-toggle="tab">Price</a>
                        </li>
                    </ul>
                </div>

                <div class="tab-content-box tab-content">
                    <div class="single-tab-content tab-pane fade in active row" id="description">
                        <div class="col-md-12">
                            <div class="content-box">
                                <?php echo $tour->description; ?>

                            </div>
                        </div>
                    </div>

                    <div class="single-tab-content tab-pane fade row" id="facilities">
                        <div class="col-md-12">
                            <div class="content-box">
                                <?php echo $tour->facilities; ?>

                            </div>
                        </div>
                    </div>

                    <div class="single-tab-content tab-pane fade row" id="schedule">
                        <div class="col-md-12">
                            <div class="content-box">
                                <?php echo $tour->schedule; ?>

                            </div>
                        </div>
                    </div>

                    <div class="single-tab-content tab-pane fade row" id="bring">
                        <div class="col-md-12">
                            <div class="content-box">
                                <?php echo $tour->bring; ?>

                            </div>
                        </div>
                    </div>

                    <div class="single-tab-content tab-pane fade row" id="term">
                        <div class="col-md-12">
                            <div class="content-box">
                                <?php echo $tour->term; ?>

                            </div>
                        </div>
                    </div>

                    <div class="single-tab-content tab-pane fade row" id="price">
                        <div class="col-md-12">
                            <div class="content-box">
                                <?php echo $tour->price; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
          
           
        </div>
           
    </div>

       <div class="col-md-4">
       
          <div class="single-sidebar-widget sroom-sidebar">         
              
            <div class="room-overview">
                <div class="book-r-form">
                  <div class="room-price">
                    <?php if(is_null($tour->fakeprice)): ?>
                        <p class="rp">Rp <?php echo e($tour->price); ?></p>
                    <?php else: ?>
                        <p class="rp" style="text-decoration: line-through;">Rp <?php echo e($tour->fakeprice); ?></p> <br>
                        <p>Rp <?php echo e($tour->price); ?></p>
                    <?php endif; ?>
                  </div>
                  
                  <div class="book-form">
                    
                    <div class="col-md-6">
                        <div class="date-icon">
                            <i class="fa fa-user">  <p><?php echo e($tour->person); ?> Person</p></i> 
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="date-icon">
                            <i class="fa fa-tag">  <p><?php echo e($tour->destination->implode('name')); ?></p></i> 
                        </div>
                    </div>
                    <?php if(auth()->guard()->guest()): ?>
                        
                        <a role="button" data-toggle="collapse" href="#sidebarCollapse" aria-expanded="false" aria-controls="sidebarCollapse" class="collapsed res-btn">Please Login to Booking <i class="fa fa-arrow-right"></i></a>
                    <?php else: ?>
                        <a href="/booking/<?php echo e($tour->id); ?>" class="res-btn">Booking Now <i class="icon icon-ShoppingCart"></i></a>
                    <?php endif; ?>
                  </div>
              
              </div>
              
            </div>

          </div>

          <!-- Have any question style-->
            <div class="single-room-wrapper">
                <div class="question-wrapper">
                   <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><h2>Have any question</h2></div>
                   
                   <div class="col-lg-6"><input type="text" class="form-control" id="name" name="name" placeholder="Name"></div>
                       
                       <div class="col-lg-6"><input type="text" class="form-control" id="email" name="name" placeholder="Email"></div>
                   
                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                           <textarea class="form-control" rows="6" id="message" name="message" placeholder="Message"></textarea>
                        </div>
                  
                      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><button type="submit" class="res-btn">Submit Now <i class="fa fa-arrow-right"></i></button></div>
                </div>
            </div>
           <!-- Have any question style-->
       </div>
      
</div>
</section> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>