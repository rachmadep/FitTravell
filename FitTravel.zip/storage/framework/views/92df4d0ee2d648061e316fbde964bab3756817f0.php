<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <!-- USER DATA-->
        <div class="user-data m-b-30">
            <div class="row">
                <div class="col-lg-6">
                    <h3 class="title-3 m-b-30">
                        <i class="zmdi zmdi-account-calendar"></i>user data
                    </h3>
                </div>
                <div class="col-lg-6">
                    <button type="button" class="btn btn-primary float-right2" data-toggle="modal" data-target="#CreateUser">
                        Create User
                    </button>
                </div>
            </div>
            
            <div class="table-responsive table-data">
                <table class="table">
                    <thead>
                        <tr>
                            <td>No</td>
                            <td>Name</td>
                            <td>Type</td>
                            <td>Action</td>
                            <td></td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($loop->iteration); ?>                               
                            </td>
                            <td>
                                <div class="table-data__info">
                                    <h6><?php echo e($value->name); ?></h6>
                                    <span>
                                        <a href="#"><?php echo e($value->email); ?></a>
                                    </span>
                                    <br>
                                    <span>
                                        <a href="#"><?php echo e($value->phone); ?></a>
                                    </span>
                                </div>
                            </td>
                            <td>
                                <span class="role <?php echo e($value->type); ?>"><?php echo e($value->type); ?></span>
                            </td>
                            
                            <td>
                                <div class="table-data-feature">
                                    <button class="item edit-user" data-toggle="modal" data-target="#EditUser" title="Edit" value="<?php echo e($value->id); ?>">
                                        <i class="zmdi zmdi-edit"></i>
                                    </button>
                                    <a haref="" class="item" title="Delete">
                                        <i class="zmdi zmdi-delete"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
            </div>
            
        </div>
        <!-- END USER DATA-->

    </div>

    
</div>
<!-- Add user modal -->
<div class="modal fade" id="CreateUser" tabindex="-1" role="dialog" aria-labelledby="largeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="largeModalLabel">Create User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" action="/adm/user/store" method="POST">
                    <?php echo csrf_field(); ?>
                      <fieldset>
                          <!-- Name input-->
                          <div class="form-group">
                              <label class="col-md-2 control-label" for="name">Name</label>
                              <div class="col-md-10">
                                  <input name="name" type="text" placeholder="Name" value="" class="form-control"></div>
                          </div>
                          <!-- Email input-->
                          <div class="form-group">
                              <label class="col-md-2 control-label" for="email">E-mail</label>
                              <div class="col-md-10">
                                  <input name="email" type="text" placeholder="E-mail" value="" class="form-control"></div>
                          </div>
                          <!-- Phone input-->
                          <div class="form-group">
                              <label class="col-md-2 control-label" for="">Phone Number</label>
                              <div class="col-md-10">
                                  <input name="phone" type="text" placeholder="Phone Number" value="" class="form-control"></div>
                          </div>                      
                         
                          <!-- Password input-->
                          <div class="form-group">
                              <label class="col-md-2 control-label" for="password">Password</label>
                              <div class="col-md-10">
                                  <input name="password" type="password" placeholder="Password" value="" class="form-control"></div>
                          </div>

                          <!-- Form actions -->
                          <div class="form-group">
                              <div class="col-md-12 text-right">
                                <input type="hidden" name="_method" value="POST">
                                
                                <button type="submit" class="btn btn-responsive btn-primary btn-md">Submit</button>
                              </div>
                          </div>
                      </fieldset>
                  </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                
            </div>
        </div>
    </div>
</div>
<!-- end Add user modal -->

<!-- Edit user modal -->
<div class="modal fade" id="EditUser" tabindex="-1" role="dialog" aria-labelledby="largeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="largeModalLabel">Edit User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" action="" method="post">
                  <fieldset>
                      <!-- Name input-->
                      <div class="form-group">
                          <label class="col-md-2 control-label" for="name">Name</label>
                          <div class="col-md-10">
                              <input id="name" name="name" type="text" placeholder="Nama" value="" class="form-control"></div>
                      </div>
                      <!-- Email input-->
                      <div class="form-group">
                          <label class="col-md-2 control-label" for="email">E-mail</label>
                          <div class="col-md-10">
                              <input id="email" name="email" type="text" placeholder="E-mail" value="" class="form-control"></div>
                      </div>
                      <!-- Phone input-->
                      <div class="form-group">
                          <label class="col-md-2 control-label" for="email">Phone Number</label>
                          <div class="col-md-10">
                              <input id="phone" name="phone" type="text" placeholder="Phone Number" value="" class="form-control"></div>
                      </div>                      
                     
                      <!-- Password input-->
                      <div class="form-group">
                          <label class="col-md-2 control-label" for="password">Password</label>
                          <div class="col-md-10">
                              <input id="password" name="password" type="password" placeholder="Biarkan kosong jika tidak ingin mengganti password" value="" class="form-control"></div>
                      </div>

                      <!-- Form actions -->
                      <div class="form-group">
                          <div class="col-md-12 text-right">
                            <input type="hidden" name="_method" value="PUT">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button type="submit" class="btn btn-responsive btn-primary btn-lg">Submit</button>
                          </div>
                      </div>
                  </fieldset>
              </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                
            </div>
        </div>
    </div>
</div>
<!-- end Edit user modal -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
  //Menampilkan Form  dan Data
  $(document).on('click','.edit-user',function(){
    var id = $(this).val();
    $.get('/adm/user/edit/'+ id , function (data) {
        console.log(data);
        var d = data.date;
        var dout = Date.parse(d);
        $('#name').attr("value", data.name);;
        $('#email').attr("value", data.email);;
        $('#phone').attr("value", data.phone);;
;
    })
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>